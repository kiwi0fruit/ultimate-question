# Modern sciense ontology is implicitly the Last Thursdayism

## (this doesn't diminish physics predictive power).

Especially multiverse paired with anthropic principle suffers from this. It happens because of the lack of solid [novelty emergence mechanics](./novelty.md). Attempts to fix it give us ad hock patches to not get [Boltzmann brain](https://en.wikipedia.org/wiki/Boltzmann_brain) variant as the most probable sentient life.
